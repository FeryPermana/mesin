<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="card pt-5">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <h3>Maintenance <strong><?php echo e($mesin->name); ?></strong></h3>
                    </div>
                </div>
                <div class="alert alert-warning text-center">
                    Harus memilih semua indikator terlebih dahulu
                </div>
                <form action="">
                    <div class="row">
                        <div class="col-md-2">
                            <select name="shift"
                                class="form-control custom-select">
                                <option value=""
                                    selected>-- Shift --</option>
                                <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sht): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sht->id); ?>"
                                        <?php echo e(@$_GET['shift'] == $sht->id ? 'selected' : ''); ?>>
                                        <?php echo e($sht->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select name="lineproduksi"
                                class="form-control custom-select">
                                <option value=""
                                    selected>-- Line Produksi --</option>
                                <?php $__currentLoopData = $lineproduksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($lps->id); ?>"
                                        <?php echo e(@$_GET['lineproduksi'] == $lps->id ? 'selected' : ''); ?>>
                                        <?php echo e($lps->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select name="bulan"
                                class="form-control custom-select">
                                <option value=""
                                    selected>-- Bulan --</option>
                                <?php $__currentLoopData = bulan_list(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($bulan); ?>"
                                        <?php echo e(@$_GET['bulan'] == $bulan ? 'selected' : ''); ?>>
                                        <?php echo e($bulan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select name="tahun"
                                class="form-control custom-select">
                                <option value=""
                                    selected>-- Tahun --</option>
                                <?php
                                    $tahunSekarang = date('Y');
                                ?>
                                <?php for($tahun = $tahunSekarang; $tahun >= 2022; $tahun--): ?>
                                    <option value="<?php echo e($tahun); ?>"
                                        <?php echo e(@$_GET['tahun'] == $tahun ? 'selected' : ''); ?>>
                                        <?php echo e($tahun); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <button type="submit"
                                class="btn btn-primary">Filter</button>
                            
                            <a href="<?php echo e(route('maintenance-mingguan.show', $mesin->id)); ?>?print=1&shift=<?php echo e(@$_GET['shift']); ?>&lineproduksi=<?php echo e(@$_GET['lineproduksi']); ?>&bulan=<?php echo e(@$_GET['bulan']); ?>&tahun=<?php echo e(@$_GET['tahun']); ?>"
                                class="btn btn-warning">Print</a>
                            <button type="submit"
                                name="image"
                                value="1"
                                class="btn btn-danger">Gambar</button>
                        </div>
                    </div>
                </form>
                <br>
                <?php if(@$_GET['lineproduksi'] && @$_GET['shift']): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <tr>
                                <th rowspan="2">No</th>
                                <th rowspan="2">
                                    <div style="width: 250px;">
                                        Jenis Kegiatan
                                    </div>
                                </th>
                                <th rowspan="2">
                                    <div>
                                        Standart
                                    </div>
                                </th>
                                <th colspan="31"
                                    class="text-center">Pelaksanaan</th>
                            </tr>
                            <tr>
                                <?php for($i = 1; $i < 5; $i++): ?>
                                    <th><?php echo e($i); ?></th>
                                <?php endfor; ?>
                            </tr>
                            <?php
                                $no = 1;
                            ?>
                            <?php $__currentLoopData = $jeniskegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($j->name); ?></td>
                                    <td><?php echo e($j->standart); ?></td>
                                    <?php $__currentLoopData = $pengerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $checklists = $p->checklistmingguan;
                                            
                                            $arraycheck = [];
                                            foreach ($checklists as $checklist) {
                                                $arraycheck[] = $checklist->is_check ? $checklist->jenis_kegiatan_id : 0;
                                            }
                                        ?>
                                        <?php if(in_array($j->id, $arraycheck)): ?>
                                            <td><i class="ti ti-check"></i></td>
                                        <?php else: ?>
                                            <td>-</td>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $p = 5 - count($pengerjaan);
                                    ?>
                                    <?php for($i = 1; $i < $p; $i++): ?>
                                        <td>-</td>
                                    <?php endfor; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td colspan="2"><strong>Keterangan</strong></td>
                                <td>Operator</td>
                                <?php $__currentLoopData = $pengerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><i class="text-sm"><?php echo e($p->keterangan); ?></i></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $p = 5 - count($pengerjaan);
                                ?>
                                <?php for($i = 1; $i < $p; $i++): ?>
                                    <td>-</td>
                                <?php endfor; ?>
                            </tr>
                            <tr>
                                <td colspan="2"><strong>Dikerjakan</strong></td>
                                <td>Operator</td>
                                <?php $__currentLoopData = $pengerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><i class="text-sm"><?php echo e($p->operator->name); ?></i></td>
                                    <?php
                                        $p = 5 - count($pengerjaan);
                                    ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php for($i = 1; $i < $p; $i++): ?>
                                    <td>-</td>
                                <?php endfor; ?>
                            </tr>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-danger">
                        <div class="text-center">
                            Data belum ada silhakan pilih indikator lain
                        </div>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH E:\Pemrograman web\localhost\projekmesin\resources\views/pages/dashboard/maintenance-mingguan/show.blade.php ENDPATH**/ ?>