<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="card">
        <div class="card-body">
            <div class="my-5">
                <div class="row">
                    <div class="col-md-6">
                        <h3>Request Perbaikan</h3>
                    </div>
                </div>
            </div>
            <br>
            <form action="">
                <div class="row">
                    <div class="col-md-3">
                        <select name="mesin"
                            class="form-control custom-select">
                            <option value=""
                                selected>-- Mesin --</option>
                            <?php $__currentLoopData = $mesin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(auth()->user()->lokasi_id == $mes->lokasi_id): ?>
                                    <option value="<?php echo e($mes->id); ?>"
                                        <?php echo e(@$_GET['mesin'] == $mes->id ? 'selected' : ''); ?>>
                                        <?php echo e($mes->name); ?>

                                    </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="shift"
                            class="form-control custom-select">
                            <option value=""
                                selected>-- Shift --</option>
                            <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sht): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sht->id); ?>"
                                    <?php echo e(@$_GET['shift'] == $sht->id ? 'selected' : ''); ?>>
                                    <?php echo e($sht->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <select name="lineproduksi"
                            class="form-control custom-select">
                            <option value=""
                                selected>-- Line Produksi --</option>
                            <?php $__currentLoopData = $lineproduksis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linpr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($linpr->id); ?>"
                                    <?php echo e(@$_GET['lineproduksi'] == $linpr->id ? 'selected' : ''); ?>>
                                    <?php echo e($linpr->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <button type="submit"
                            class="btn btn-primary">Filter</button>
                    </div>
                </div>
            </form>
            <br>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>
                                <div style="width: 200px;">
                                    Mesin
                                </div>
                            </th>
                            <th>
                                <div style="width: 50px;">
                                    Line
                                </div>
                            </th>
                            <th>
                                <div style="width: 60px;">
                                    Lokasi
                                </div>
                            </th>
                            <th>
                                <div style="width: 60px;">
                                    Shift
                                </div>
                            </th>
                            <th>
                                <div style="width: 70px;">
                                    Tanggal Request
                                </div>
                            </th>
                            <th>
                                <div style="width: 200px;">
                                    Tanggal Update
                                </div>
                            </th>
                            <th>
                                <div style="width: 200px;">
                                    Action Perbaikan
                                </div>
                            </th>
                            <th>
                                <div style="width: 200px">
                                    Pergantian Spare
                                </div>
                            </th>
                            <th>Status</th>
                            <th>
                                <div style="width: 200px">
                                    Lama Waktu
                                </div>
                            </th>
                            <th>
                                <div style="width: 200px">
                                    Kerusakan
                                </div>
                            </th>
                            <th>Gambar</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $perbaikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($perb->mesin->name); ?></td>
                                <td><?php echo e($perb->lineproduksi->name); ?></td>
                                <td><?php echo e($perb->mesin->lokasi->lokasi); ?></td>
                                <td><?php echo e($perb->shift->name); ?></td>
                                <td><?php echo e($perb->tanggal_request); ?></td>
                                <td><?php echo e($perb->tanggal_update); ?></td>
                                <td><?php echo e($perb->action); ?></td>
                                <td><?php echo e($perb->pergantian_spare); ?></td>
                                <td>
                                    <?php if(@$perb->status == 3): ?>
                                        Waiting
                                    <?php elseif(@$perb->status == 2): ?>
                                        Closed
                                    <?php else: ?>
                                        Open
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($perb->lama_waktu); ?></td>
                                <td><?php echo e($perb->downtime); ?></td>
                                <td>
                                    <img src="<?php echo e(asset($perb->gambar)); ?>"
                                        alt=""
                                        width="100">
                                </td>
                                <td>
                                    <a href="<?php echo e(route('teknisi-perbaikan.edit', $perb->id)); ?>"
                                        class="btn btn-warning">Edit</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH E:\Pemrograman web\localhost\projekmesin\resources\views/pages/dashboard/teknisi-perbaikan/index.blade.php ENDPATH**/ ?>