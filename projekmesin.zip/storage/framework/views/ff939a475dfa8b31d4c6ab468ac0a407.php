<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="card pt-5">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <h3>Perbaikan <strong><?php echo e($mesin->name); ?></strong></h3>
                    </div>
                </div>
                <div class="alert alert-warning text-center">
                    Harus memilih semua indikator terlebih dahulu
                </div>
                <form action="">
                    <div class="row">
                        <div class="col-md-2">
                            <select name="shift"
                                onchange="this.form.submit()"
                                class="form-control custom-select">
                                <option value=""
                                    selected>-- Shift --</option>
                                <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sht): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sht->id); ?>"
                                        <?php echo e(@$_GET['shift'] == $sht->id ? 'selected' : ''); ?>>
                                        <?php echo e($sht->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select name="lineproduksi"
                                class="form-control custom-select"
                                onchange="this.form.submit()">
                                <option value=""
                                    selected>-- Line Produksi --</option>
                                <?php $__currentLoopData = $lineproduksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($lps->id); ?>"
                                        <?php echo e(@$_GET['lineproduksi'] == $lps->id ? 'selected' : ''); ?>>
                                        <?php echo e($lps->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-3 pr-md-0 mb-3 mb-md-0">
                            <select name="status"
                                class="form-control custom-select"
                                onchange="this.form.submit()">
                                <option value=""
                                    selected>Status</option>
                                <option value="1"
                                    <?php echo e(@$_GET['status'] == 1 ? 'selected' : ''); ?>>
                                    Open
                                </option>
                                <option value="2"
                                    <?php echo e(@$_GET['status'] == 1 ? 'selected' : ''); ?>>
                                    Closed
                                </option>
                                <option value="3"
                                    <?php echo e(@$_GET['status'] == 1 ? 'selected' : ''); ?>>
                                    Waiting
                                </option>
                            </select>
                        </div>

                        
                        <div class="col-md-4">
                            <a href="<?php echo e(route('request-perbaikan.show', $mesin->id)); ?>?export-perbaikan=1&shift=<?php echo e(@$_GET['shift']); ?>&lineproduksi=<?php echo e(@$_GET['lineproduksi']); ?>"
                                class="btn btn-success">Excel</a>
                            <button type="submit"
                                name="image"
                                value="1"
                                class="btn btn-danger">Gambar</button>
                        </div>
                    </div>
                </form>
                <br>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>
                                    <div style="width: 50px;">
                                        Line
                                    </div>
                                </th>
                                <th>
                                    <div style="width: 60px;">
                                        Lokasi
                                    </div>
                                </th>
                                <th>
                                    <div style="width: 60px;">
                                        Shift
                                    </div>
                                </th>
                                <th>
                                    <div style="width: 70px;">
                                        Tanggal Request
                                    </div>
                                </th>
                                <th>
                                    <div style="width: 200px;">
                                        Tanggal Update
                                    </div>
                                </th>
                                <th>
                                    <div style="width: 200px;">
                                        Lama Waktu
                                    </div>
                                </th>
                                <th>
                                    Operator
                                </th>
                                <th>
                                    Teknisi
                                </th>
                                <th>
                                    <div style="width: 200px;">
                                        Action Perbaikan
                                    </div>
                                </th>
                                <th>
                                    <div style="width: 200px">
                                        Pergantian Spare
                                    </div>
                                </th>
                                <th>
                                    <div style="width: 200px">
                                        Kerusakan
                                    </div>
                                </th>
                                <th>
                                    <div style="width: 200px;">
                                        Status
                                    </div>
                                </th>
                                <th>Gambar</th>
                                <th>Print</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $perbaikan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(@$perb->lineproduksi->name); ?></td>
                                    <td><?php echo e(@$perb->mesin->lokasi->lokasi); ?></td>
                                    <td><?php echo e(@$perb->shift->name); ?></td>
                                    <td><?php echo e(@$perb->tanggal_request); ?></td>
                                    <td><?php echo e(@$perb->tanggal_update); ?></td>
                                    <td><?php echo e(@$perb->lama_waktu); ?></td>
                                    <td><?php echo e(@$perb->operator->name); ?></td>
                                    <td><?php echo e(@$perb->teknisi->name); ?></td>
                                    <td><?php echo e(@$perb->action); ?></td>
                                    <td><?php echo e(@$perb->pergantian_spare); ?></td>
                                    <td><?php echo e(@$perb->downtime); ?></td>
                                    <td>
                                        <select name="status"
                                            id="status"
                                            class="form-control"
                                            onchange="changestatus(`<?php echo e($perb->id); ?>`)">
                                            <option value="1"
                                                <?php echo e($perb->status == 1 ? 'selected' : ''); ?>>Open</option>
                                            <option value="2"
                                                <?php echo e($perb->status == 2 ? 'selected' : ''); ?>>Closed</option>
                                            <option value="3"
                                                <?php echo e($perb->status == 3 ? 'selected' : ''); ?>>Waiting</option>
                                        </select>
                                    </td>
                                    <td>
                                        <img src="<?php echo e(asset($perb->gambar)); ?>"
                                            alt=""
                                            width="100">
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('request-perbaikan.print', @$perb->id)); ?>"
                                            class="btn btn-warning">Print</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script>
            function changestatus(perbaikan_id) {
                var dataToSend = {
                    status: $('#status').val(),
                };

                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo csrf_token(); ?>',
                    }
                })

                $.ajax({
                    type: 'PUT',
                    url: `<?php echo e(url('/dashboard/request-perbaikan/${perbaikan_id}')); ?>`,
                    data: dataToSend,
                    dataType: 'json',
                    success: function(response) {
                        Swal.fire({
                            position: 'top-center',
                            icon: 'success',
                            title: 'Berhasil mengubah status !!',
                            showConfirmButton: false,
                            timer: 1500
                        })
                    }
                });
            }
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH E:\Pemrograman web\localhost\projekmesin\resources\views/pages/dashboard/perbaikan/show.blade.php ENDPATH**/ ?>