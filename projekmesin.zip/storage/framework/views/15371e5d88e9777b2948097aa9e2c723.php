<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="card">
        <div class="card-body">
            <div class="my-5">
                <div class="row">
                    <div class="col-6">
                        <h3>List Spare Part</h3>
                    </div>
                </div>
            </div>
            <form>
                <div class="row">
                    <div class="col-2 pr-md-0 mb-3 mb-md-0">
                        <?php
                            $rows = [10, 50, 100, 500];
                        ?>
                        <select name="row"
                            class="form-control custom-select"
                            onchange="this.form.submit()">
                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row); ?>"
                                    <?php echo e(@$_GET['row'] == $row ? 'selected' : ''); ?>>
                                    <?php echo e($row); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3 ml-auto">
                        <div class="custom-search">
                            <input type="text"
                                class="form-control"
                                name="search"
                                placeholder="Cari nama..."
                                value="<?php echo e(@$_GET['search']); ?>">
                        </div>
                    </div>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table table-bordered"
                    style="width: max-content;">
                    <thead>
                        <th>No</th>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Stock Update</th>
                        <th>Shift</th>
                        <th>Alokasi Line</th>
                        <th>Tanggal Update Keluar</th>
                        <th>Keterangan</th>
                        <th>Aksi</th>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $sparepart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(increment($sparepart, $loop)); ?></td>
                                <td><?php echo e($s->kode_barang ?? '-'); ?></td>
                                <td><?php echo e($s->item ?? '-'); ?></td>
                                <td><?php echo e($s->stock ?? '-'); ?></td>
                                <td><?php echo e(@$s->shift->name ?? '-'); ?></td>
                                <td><?php echo e(@$s->lineproduksi->name ?? '-'); ?></td>
                                <td><?php echo e(formatTanggalIndo($s->tanggal_keluar)); ?></td>
                                <td><?php echo e($s->keterangan ?? '-'); ?></td>
                                <td>
                                    <a href="<?php echo e(route('teknisi-sparepart.edit', $s->id)); ?>"
                                        class="btn btn-warning btn-sm"><i class="ti ti-pencil"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9">
                                    <div class="text-center">
                                        <div class="alert alert-warning"
                                            role="alert">
                                            Data tidak ada
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-end">
                <?php echo e($sparepart->withQueryString()->links()); ?>

            </div>

        </div>
    </div>
    <?php echo $__env->make('pages.partials.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH E:\Pemrograman web\localhost\projekmesin\resources\views/pages/dashboard/teknisi-sparepart/index.blade.php ENDPATH**/ ?>