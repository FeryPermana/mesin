<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="card pt-5">
            <div class="card-body">
                <div class="row">
                    <?php
                        $date = new DateTime($pengerjaan[0]->tanggal ?? '');
                        $monthYearString = generateMonthYearStringFromDate($date);
                    ?>
                    <div class="col-md-12">
                        <h3>Maintenance mesin <strong><?php echo e($mesin->name); ?></strong></h3>
                        <p>Bulan / Tahun : <?php echo e(@$_GET['bulan']); ?> <?php echo e(@$_GET['tahun']); ?> </p>
                    </div>
                </div>
                <form action="">
                    <div class="row">
                        <div class="col-md-2">
                            <select name="shift"
                                class="form-control custom-select">
                                <option value=""
                                    selected>-- Shift --</option>
                                <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sht): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sht->id); ?>"
                                        <?php echo e(@$_GET['shift'] == $sht->id ? 'selected' : ''); ?>>
                                        <?php echo e($sht->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select name="lineproduksi"
                                class="form-control custom-select">
                                <option value=""
                                    selected>-- Line Produksi --</option>
                                <?php $__currentLoopData = $lineproduksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($lps->id); ?>"
                                        <?php echo e(@$_GET['lineproduksi'] == $lps->id ? 'selected' : ''); ?>>
                                        <?php echo e($lps->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select name="bulan"
                                class="form-control custom-select">
                                <option value=""
                                    selected>-- Bulan --</option>
                                <?php $__currentLoopData = bulan_list(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($bulan); ?>"
                                        <?php echo e(@$_GET['bulan'] == $bulan ? 'selected' : ''); ?>>
                                        <?php echo e($bulan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select name="tahun"
                                class="form-control custom-select">
                                <option value=""
                                    selected>-- Tahun --</option>
                                <?php
                                    $tahunSekarang = date('Y');
                                ?>
                                <?php for($tahun = $tahunSekarang; $tahun >= 2022; $tahun--): ?>
                                    <option value="<?php echo e($tahun); ?>"
                                        <?php echo e(@$_GET['tahun'] == $tahun ? 'selected' : ''); ?>>
                                        <?php echo e($tahun); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <button type="submit"
                                class="btn btn-primary">Filter</button>
                            
                            <button type="submit"
                                name="image"
                                value="1"
                                class="btn btn-danger">Gambar</button>
                        </div>
                    </div>
                </form>
                <br>
                <div class="row">
                    <?php $__currentLoopData = $pengerjaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mt-3">
                            <img src="<?php echo e(asset($p->gambar)); ?>"
                                alt=""
                                width="100%"
                                class="img-thumbnail">
                            <p class="text-center"><?php echo e($p->tanggal); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH E:\Pemrograman web\localhost\projekmesin\resources\views/pages/dashboard/maintenance-mingguan/image.blade.php ENDPATH**/ ?>