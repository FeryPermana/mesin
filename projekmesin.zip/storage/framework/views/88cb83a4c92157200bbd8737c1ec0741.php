<nav class="sidebar-nav scroll-sidebar"
    data-simplebar="">
    <ul id="sidebarnav">
        
        <?php if(auth()->user()->role == '1'): ?>
            <?php echo $__env->make('layouts.partials.menu-supadm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if(auth()->user()->role == '2'): ?>
            <?php echo $__env->make('layouts.partials.menu-kabag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if(auth()->user()->role == '3'): ?>
            <?php echo $__env->make('layouts.partials.menu-teknisi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if(auth()->user()->role == '4'): ?>
            <?php echo $__env->make('layouts.partials.menu-fa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php if(auth()->user()->role == '5'): ?>
            <?php echo $__env->make('layouts.partials.menu-operator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
    </ul>
</nav>
<?php /**PATH E:\Pemrograman web\localhost\projekmesin\resources\views/layouts/partials/sidebar.blade.php ENDPATH**/ ?>