<li class="sidebar-item">
    <a class="sidebar-link <?php echo e(request()->routeIs('reject-operator.create') ? 'active' : ''); ?>" href="<?php echo e(route('reject-operator.create')); ?>" aria-expanded="false">
        <span>
            <i class="ti ti-layout-dashboard"></i>
        </span>
        <span class="hide-menu">Input Reject</span>
    </a>
</li>
<li class="sidebar-item">
    <a class="sidebar-link <?php echo e(request()->routeIs('reject-operator.index') ? 'active' : ''); ?>" href="<?php echo e(route('reject-operator.index')); ?>" aria-expanded="false">
        <span>
            <i class="ti ti-layout-dashboard"></i>
        </span>
        <span class="hide-menu">Data Reject</span>
    </a>
</li>
<li class="sidebar-item">
    <a class="sidebar-link <?php echo e(request()->routeIs('tutorial-mesin.*') ? 'active' : ''); ?>" href="<?php echo e(route('tutorial-mesin.index')); ?>" aria-expanded="false">
        <span>
            <i class="ti ti-video"></i>
        </span>
        <span class="hide-menu">Tutorial Mesin</span>
    </a>
</li>
<li class="sidebar-item">
    <a class="sidebar-link <?php echo e(request()->routeIs('presensi.*') ? 'active' : ''); ?>" href="<?php echo e(route('presensi.index')); ?>" aria-expanded="false">
        <span>
            <i class="ti ti-star"></i>
        </span>
        <span class="hide-menu">Presensi</span>
    </a>
</li>
<li class="sidebar-item">
    <a class="sidebar-link <?php echo e(request()->routeIs('perawatan.*') ? 'active' : ''); ?>" href="<?php echo e(route('perawatan.index')); ?>" aria-expanded="false">
        <span>
            <i class="ti ti-article"></i>
        </span>
        <span class="hide-menu">Perawatan Harian</span>
    </a>
</li>

<li class="sidebar-item">
    <a class="sidebar-link <?php echo e(request()->routeIs('operator-perbaikan.*') ? 'active' : ''); ?>" href="<?php echo e(route('operator-perbaikan.index')); ?>" aria-expanded="false">
        <span>
            <i class="ti ti-article"></i>
        </span>
        <span class="hide-menu">Permintaan Perbaikan</span>
    </a>
</li>
<li class="sidebar-item">
    <a class="sidebar-link <?php echo e(request()->routeIs('monitoring-suhu.*') ? 'active' : ''); ?>" href="<?php echo e(route('monitoring-suhu.index')); ?>" aria-expanded="false">
        <span>
            <i class="ti ti-aperture"></i>
        </span>
        <span class="hide-menu">Monitoring Suhu</span>
    </a>
</li><?php /**PATH E:\Pemrograman web\localhost\projekmesin\resources\views/layouts/partials/menu-operator.blade.php ENDPATH**/ ?>