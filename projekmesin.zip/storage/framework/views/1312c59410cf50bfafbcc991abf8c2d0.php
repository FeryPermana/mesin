<li class="nav-small-cap">
    <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
    <span class="hide-menu">MASTER</span>
</li>
<li class="sidebar-item">
    <a class="sidebar-link <?php echo e(request()->routeIs('teknisi-downtime.*') ? 'active' : ''); ?>"
        href="<?php echo e(route('teknisi-downtime.index')); ?>"
        aria-expanded="false">
        <span>
            <i class="ti ti-clock-stop"></i>
        </span>
        <span class="hide-menu">Input Downtime</span>
    </a>
</li>
<li class="sidebar-item">
    <a class="sidebar-link <?php echo e(request()->routeIs('tutorial-mesin.*') ? 'active' : ''); ?>"
        href="<?php echo e(route('tutorial-mesin.index')); ?>"
        aria-expanded="false">
        <span>
            <i class="ti ti-video"></i>
        </span>
        <span class="hide-menu">Tutorial Mesin</span>
    </a>
</li>
<li class="sidebar-item">
    <a class="sidebar-link <?php echo e(request()->routeIs('presensi.*') ? 'active' : ''); ?>"
        href="<?php echo e(route('presensi.index')); ?>"
        aria-expanded="false">
        <span>
            <i class="ti ti-star"></i>
        </span>
        <span class="hide-menu">Presensi</span>
    </a>
</li>
<li class="sidebar-item">
    <a class="sidebar-link <?php echo e(request()->routeIs('teknisi-sparepart.*') ? 'active' : ''); ?>"
        href="<?php echo e(route('teknisi-sparepart.index')); ?>"
        aria-expanded="false">
        <span>
            <i class="ti ti-tool"></i>
        </span>
        <span class="hide-menu">Spare Part</span>
    </a>
</li>
<li class="sidebar-item">
    <a class="sidebar-link <?php echo e(request()->routeIs('perawatan-mingguan.*') ? 'active' : ''); ?>"
        href="<?php echo e(route('perawatan-mingguan.index')); ?>"
        aria-expanded="false">
        <span>
            <i class="ti ti-article"></i>
        </span>
        <span class="hide-menu">Perawatan Mingguan</span>
    </a>
</li>
<li class="sidebar-item">
    <a class="sidebar-link <?php echo e(request()->routeIs('perawatan-bulanan.*') ? 'active' : ''); ?>"
        href="<?php echo e(route('perawatan-bulanan.index')); ?>"
        aria-expanded="false">
        <span>
            <i class="ti ti-article"></i>
        </span>
        <span class="hide-menu">Perawatan Bulanan</span>
    </a>
</li>
<li class="sidebar-item">
    <a class="sidebar-link <?php echo e(request()->routeIs('teknisi-perbaikan.*') ? 'active' : ''); ?>"
        href="<?php echo e(route('teknisi-perbaikan.index')); ?>"
        aria-expanded="false">
        <span>
            <i class="ti ti-article"></i>
        </span>
        <span class="hide-menu">Permintaan Perbaikan</span>
    </a>
</li>
<?php /**PATH E:\Pemrograman web\localhost\projekmesin\resources\views/layouts/partials/menu-teknisi.blade.php ENDPATH**/ ?>