<div class="table-responsive">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th colspan="9"
                    style="text-align: center;">
                    Downtime <?php echo e($perawatan[0]->mesin->name); ?>

                </th>
            </tr>
            <tr>
                <th>
                    <div style="width: 50px;">
                        Line
                    </div>
                </th>
                <th>
                    <div style="width: 60px;">
                        Lokasi
                    </div>
                </th>
                <th>
                    <div style="width: 60px;">
                        Shift
                    </div>
                </th>
                <th>
                    <div style="width: 70px;">
                        Jam Kerja
                    </div>
                </th>
                <th>
                    <div style="width: 200px;">
                        Downtime
                    </div>
                </th>
                <th>
                    <div style="width: 200px;">
                        Mulai
                    </div>
                </th>
                <th>
                    <div style="width: 200px">
                        Finish
                    </div>
                </th>
                <th>
                    <div style="width: 200px;">
                        Action Plan
                    </div>
                </th>
                <th>
                    <div style="width: 200px;">
                        Lama Waktu
                    </div>
                </th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $perawatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($prw->lineproduksi->name); ?></td>
                    <td><?php echo e($prw->lokasi->lokasi); ?></td>
                    <td><?php echo e($prw->shift->name); ?></td>
                    <td><?php echo e($prw->jamkerja->name); ?></td>
                    <td><?php echo e($prw->downtime->name); ?></td>
                    <td><?php echo e($prw->tanggal); ?></td>
                    <td><?php echo e($prw->finish); ?></td>
                    <td><?php echo e($prw->action_plan); ?></td>
                    <td><?php echo e($prw->lama_waktu); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH E:\Pemrograman web\localhost\projekmesin\resources\views/exports/downtime.blade.php ENDPATH**/ ?>