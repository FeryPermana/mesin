<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="card">
        <div class="card-body">
            <div class="my-5">
                <div class="row">
                    <div class="col-md-6">
                        <h3>Maintenance Harian</h3>
                    </div>
                </div>
            </div>
            <form>
                <div class="row my-5">
                    <div class="col-2 pr-md-0 mb-3 mb-md-0">
                        <?php
                            $rows = [10, 50, 100, 500];
                        ?>
                        <select name="row"
                            class="form-control custom-select"
                            onchange="this.form.submit()">
                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row); ?>"
                                    <?php echo e(@$_GET['row'] == $row ? 'selected' : ''); ?>>
                                    <?php echo e($row); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-3 pr-md-0 mb-3 mb-md-0">
                        <select name="mesin"
                            class="form-control custom-select"
                            onchange="this.form.submit()">
                            <option value=""
                                selected>Mesin</option>
                            <?php $__currentLoopData = $mesin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mes->id); ?>"
                                    <?php echo e(@$_GET['mesin'] == $mes->id ? 'selected' : ''); ?>>
                                    <?php echo e($mes->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-md-5 ml-auto">
                        <div class="custom-search">
                            <input type="text"
                                class="form-control"
                                name="search"
                                placeholder="Cari nama..."
                                value="<?php echo e(@$_GET['search']); ?>">
                        </div>
                    </div>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <th>Nama</th>
                        <th>Merk</th>
                        <th>Lokasi</th>
                        <th>Tahun Pembuatan</th>
                        <th>Periode Pakai</th>
                        <th>Aksi</th>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $maintenance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php if(auth()->user()->role != 1): ?>
                                <?php if(auth()->user()->lokasi_id == $m[0]->mesin->lokasi_id): ?>
                                    <tr>
                                        <td><?php echo e($m[0]->mesin->name); ?></td>
                                        <td><?php echo e($m[0]->mesin->merk); ?></td>
                                        <td><?php echo e($m[0]->mesin->lokasi->lokasi); ?></td>
                                        <td><?php echo e($m[0]->mesin->tahun_pembuatan); ?></td>
                                        <td><?php echo e($m[0]->mesin->periode_pakai); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('maintenance-harian.show', $m[0]->mesin->id)); ?>"
                                                class="btn btn-warning">Detail</a>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php else: ?>
                                <tr>
                                    <td><?php echo e($m[0]->mesin->name); ?></td>
                                    <td><?php echo e($m[0]->mesin->merk); ?></td>
                                    <td><?php echo e($m[0]->mesin->lokasi->lokasi); ?></td>
                                    <td><?php echo e($m[0]->mesin->tahun_pembuatan); ?></td>
                                    <td><?php echo e($m[0]->mesin->periode_pakai); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('maintenance-harian.show', $m[0]->mesin->id)); ?>"
                                            class="btn btn-warning">Detail</a>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6">
                                    <div class="text-center">
                                        <div class="alert alert-warning"
                                            role="alert">
                                            Data tidak ada
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>
    <?php echo $__env->make('pages.partials.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH E:\Pemrograman web\localhost\projekmesin\resources\views/pages/dashboard/maintenance-harian/index.blade.php ENDPATH**/ ?>