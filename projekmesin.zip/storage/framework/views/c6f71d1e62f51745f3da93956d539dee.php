<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="card">
        <div class="card-body">
            <div class="my-5">
                <div class="row">
                    <div class="col-md-6">
                        <h3>Report Monitoring Suhu</h3>
                    </div>
                </div>
            </div>
            <form>
                <div class="row my-5">
                    <div class="col-2 mt-2">
                        <?php
                            $rows = [10, 50, 100, 500];
                        ?>
                        <select name="row"
                            class="form-control custom-select"
                            onchange="this.form.submit()">
                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row); ?>"
                                    <?php echo e(@$_GET['row'] == $row ? 'selected' : ''); ?>>
                                    <?php echo e($row); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-3 mt-2">
                        <select name="operator"
                            class="form-control custom-select"
                            onchange="this.form.submit()">
                            <option value=""
                                selected>Operator</option>
                            <?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($operator->id); ?>"
                                    <?php echo e(@$_GET['operator'] == $operator->id ? 'selected' : ''); ?>>
                                    <?php echo e($operator->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-3 mt-2">
                        <select name="lineproduksi"
                            class="form-control custom-select"
                            onchange="this.form.submit()">
                            <option value=""
                                selected>Line Produksi</option>
                            <?php $__currentLoopData = $lineproduksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($lp->id); ?>"
                                    <?php echo e(@$_GET['lp'] == $lp->id ? 'selected' : ''); ?>>
                                    <?php echo e($lp->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-3 mt-2">
                        <select name="shift"
                            class="form-control custom-select"
                            onchange="this.form.submit()">
                            <option value=""
                                selected>Shift</option>
                            <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shift): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($shift->id); ?>"
                                    <?php echo e(@$_GET['shift'] == $shift->id ? 'selected' : ''); ?>>
                                    <?php echo e($shift->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-3 mt-2">
                        <select name="bulan"
                            class="form-control custom-select"
                            onchange="this.form.submit()">
                            <option value=""
                                selected>-- Bulan --</option>
                            <?php $__currentLoopData = bulan_list(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($bulan); ?>"
                                    <?php echo e(@$_GET['bulan'] == $bulan ? 'selected' : ''); ?>>
                                    <?php echo e($bulan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-3 mt-2">
                        <select name="tahun"
                            class="form-control custom-select"
                            onchange="this.form.submit()">
                            <option value=""
                                selected>-- Tahun --</option>
                            <?php
                                $tahunSekarang = date('Y');
                            ?>
                            <?php for($tahun = $tahunSekarang; $tahun >= 2022; $tahun--): ?>
                                <option value="<?php echo e($tahun); ?>"
                                    <?php echo e(@$_GET['tahun'] == $tahun ? 'selected' : ''); ?>>
                                    <?php echo e($tahun); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col-2 mt-2">
                        <button class="btn btn-warning"
                            onclick="this.form.submit()"
                            name="print"
                            value="1">Print</button>
                    </div>
                </div>
            </form>
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <th>Tanggal</th>
                        <th>Suhu</th>
                        <th>Rh</th>
                        <th>Operator</th>
                        <th>Keterangan</th>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $monitoringsuhu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($ms->tanggal); ?></td>
                                <td><?php echo e($ms->suhu); ?></td>
                                <td><?php echo e($ms->rh); ?></td>
                                <td><?php echo e($ms->operator->name); ?></td>
                                <td><?php echo e($ms->keterangan); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5">
                                    <div class="text-center">
                                        <div class="alert alert-warning"
                                            role="alert">
                                            Data tidak ada
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="d-flex justify-content-end">
                <?php echo e($monitoringsuhu->withQueryString()->links()); ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH E:\Pemrograman web\localhost\projekmesin\resources\views/pages/dashboard/report-suhu/index.blade.php ENDPATH**/ ?>