<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="card">
        <div class="card-body">
            <div class="my-5">
                <div class="row">
                    <div class="col-md-6">
                        <h3><?php echo e($method == 'update' ? 'Ubah Mesin' : 'Tambah Mesin'); ?></h3>
                        <a href="<?php echo e(route('jenis-kegiatan.index')); ?>"
                            class="btn btn-success">Atur disini untuk jenis kegiatan</a>
                    </div>
                    <div class="col-md-6 text-end">
                        <a href="<?php echo e(route('mesin.index')); ?>"
                            class="btn btn-primary">Kembali</a>
                    </div>
                </div>
            </div>
            <form action="<?php echo e($url); ?>"
                method="POST">
                <?php echo csrf_field(); ?>
                <?php if($method == 'update'): ?>
                    <?php echo method_field('PUT'); ?>
                <?php endif; ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label for="name"
                                class="form-label">Nama</label>
                            <input type="text"
                                name="name"
                                class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="name"
                                value="<?php echo e(old('name', @$mesin->name)); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="name"
                                    class="form-text text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <label class="form-label">Line Produksi</label>
                        <div class="row"
                            id="checkline">
                            <div class="col-12 mb-2">
                                <input type="checkbox"
                                    id="selectLine"
                                    type="checkbox">
                                &nbsp;&nbsp;Centang Semua
                            </div>
                            <?php $__currentLoopData = $lineproduksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $hasline = App\Models\HasLine::where('mesin_id', @$mesin->id)
                                        ->where('lineproduksi_id', $lp->id)
                                        ->first();
                                ?>
                                <div class="col-6 mb-2">
                                    <input type="checkbox"
                                        name="lineproduksi[]"
                                        value="<?php echo e($lp->id); ?>"
                                        <?php echo e($hasline ? 'checked' : ''); ?>>
                                    &nbsp;&nbsp;<?php echo e($lp->name); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="mb-3">
                            <label for="merk"
                                class="form-label">Merk</label>
                            <input type="text"
                                name="merk"
                                class="form-control <?php $__errorArgs = ['merk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="merk"
                                value="<?php echo e(old('merk', @$mesin->merk)); ?>">
                            <?php $__errorArgs = ['merk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="merk"
                                    class="form-text text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="kapasitas"
                                class="form-label">Kapasitas</label>
                            <input type="text"
                                name="kapasitas"
                                class="form-control <?php $__errorArgs = ['kapasitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="kapasitas"
                                value="<?php echo e(old('kapasitas', @$mesin->kapasitas)); ?>">
                            <?php $__errorArgs = ['kapasitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="kapasitas"
                                    class="form-text text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php if(@$user->role == 2 || @$user->role == ''): ?>
                            <div class="mb-3">
                                <label for="lokasi"
                                    class="form-label">Lokasi</label>
                                <select name="lokasi"
                                    id="lokasi"
                                    class="form-control <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value=""
                                        disabled
                                        selected>-- Pilih Lokasi --</option>
                                    <?php $__currentLoopData = $lokasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($l->id); ?>"
                                            <?php echo e(old('lokasi_id', @$mesin->lokasi_id) == $l->id ? 'selected' : ''); ?>>
                                            <?php echo e($l->lokasi); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['lokasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div id="lokasi"
                                        class="form-text text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        <?php endif; ?>
                        <div class="mb-3">
                            <label for="tahun_pembuatan"
                                class="form-label">Tahun Pembuatan</label>
                            <input type="text"
                                name="tahun_pembuatan"
                                class="form-control <?php $__errorArgs = ['tahun_pembuatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="tahun_pembuatan"
                                value="<?php echo e(old('tahun_pembuatan', @$mesin->tahun_pembuatan)); ?>"
                                placeholder="2023">
                            <?php $__errorArgs = ['tahun_pembuatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="tahun_pembuatan"
                                    class="form-text text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="periode_pakai"
                                class="form-label">Periode Pakai</label>
                            <input type="text"
                                name="periode_pakai"
                                class="form-control <?php $__errorArgs = ['periode_pakai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                id="periode_pakai"
                                value="<?php echo e(old('periode_pakai', @$mesin->periode_pakai)); ?>"
                                placeholder="2025">
                            <?php $__errorArgs = ['periode_pakai'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div id="periode_pakai"
                                    class="form-text text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <?php if($method == 'update'): ?>
                            <input type="hidden"
                                name="type"
                                value="<?php echo e(@$_GET['type']); ?>">
                            <div class="mb-3">
                                <label for="bulan"
                                    class="form-label">Bulan</label>
                                <select name="bulan"
                                    id="bulan"
                                    class="form-control <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value=""
                                        disabled
                                        selected>-- Pilih Bulan --</option>
                                    <?php $__currentLoopData = $bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($b); ?>"
                                            <?php echo e($b == bulanSaatIni() ? 'selected' : ''); ?>>
                                            <?php echo e($b); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['bulan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div id="bulan"
                                        class="form-text text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <label class="form-label">Jenis Checklist</label>
                            <br>
                            <a href="<?php echo e(route('mesin.edit', $mesin->id)); ?>?type=harian"
                                class="btn <?php echo e(@$_GET['type'] == 'harian' ? 'btn-primary' : 'btn-outline-primary'); ?>">Harian</a>
                            <a href="<?php echo e(route('mesin.edit', $mesin->id)); ?>?type=mingguan"
                                class="btn <?php echo e(@$_GET['type'] == 'mingguan' ? 'btn-primary' : 'btn-outline-primary'); ?>">Mingguan</a>
                            <a href="<?php echo e(route('mesin.edit', $mesin->id)); ?>?type=bulanan"
                                class="btn <?php echo e(@$_GET['type'] == 'bulanan' ? 'btn-primary' : 'btn-outline-primary'); ?>">Bulanan</a>
                            <br><br>
                            <label class="form-label">Jenis Kegiatan</label>
                            <table class="table table-bordered"
                                id="selectJenisKegiatan">
                                <tr>
                                    <td>
                                        <input type="checkbox"
                                            id="selectAll"
                                            type="checkbox">
                                    </td>
                                    <td>Centang Semua</td>
                                    <td></td>
                                </tr>
                                <?php $__currentLoopData = $jeniskegiatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $jeniskegiatanmesin = App\Models\JenisKegiatanMesin::where('mesin_id', @$mesin->id)
                                            ->where('jenis_kegiatan_id', $jk->id)
                                            ->where('bulan', @$_GET['bulan'] ?? bulanSaatIni())
                                            ->where('tahun', date('Y'))
                                            ->where('type', @$_GET['type'])
                                            ->first();
                                    ?>
                                    <tr>
                                        <td><input type="checkbox"
                                                name="jenis_kegiatan[]"
                                                value="<?php echo e($jk->id); ?>"
                                                <?php echo e($jeniskegiatanmesin ? 'checked' : ''); ?>></td>
                                        <td><?php echo e($jk->name); ?></td>
                                        <td><?php echo e($jk->standart); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
                <button type="submit"
                    class="btn btn-primary">Simpan</button>
            </form>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $("#selectAll").click(function() {
                $("#selectJenisKegiatan input[type=checkbox]").prop('checked', $(this).prop('checked'));
            });
            $("#selectLine").click(function() {
                $("#checkline input[type=checkbox]").prop('checked', $(this).prop('checked'));
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH E:\Pemrograman web\localhost\projekmesin\resources\views/pages/dashboard/mesin/_form.blade.php ENDPATH**/ ?>