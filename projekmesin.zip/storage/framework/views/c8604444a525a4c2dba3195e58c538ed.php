<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="card pt-5">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <h3>Maintenance <strong><?php echo e($mesin->name); ?></strong></h3>
                    </div>
                </div>
                <div class="alert alert-warning text-center">
                    Harus memilih semua indikator terlebih dahulu
                </div>
                <form action="">
                    <div class="row">
                        <div class="col-md-2">
                            <select name="shift"
                                class="form-control custom-select">
                                <option value=""
                                    selected>-- Shift --</option>
                                <?php $__currentLoopData = $shift; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sht): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sht->id); ?>"
                                        <?php echo e(@$_GET['shift'] == $sht->id ? 'selected' : ''); ?>>
                                        <?php echo e($sht->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <select name="lineproduksi"
                                class="form-control custom-select">
                                <option value=""
                                    selected>-- Line Produksi --</option>
                                <?php $__currentLoopData = $lineproduksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($lps->id); ?>"
                                        <?php echo e(@$_GET['lineproduksi'] == $lps->id ? 'selected' : ''); ?>>
                                        <?php echo e($lps->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                        <div class="col-md-4">
                            <button type="submit"
                                class="btn btn-primary">Filter</button>
                            <a href="<?php echo e(route('maintenance-downtime.show', $mesin->id)); ?>?export-downtime=1&shift=<?php echo e(@$_GET['shift']); ?>&lineproduksi=<?php echo e(@$_GET['lineproduksi']); ?>"
                                class="btn btn-success">Excel</a>
                            <button type="submit"
                                name="image"
                                value="1"
                                class="btn btn-danger">Gambar</button>
                        </div>
                    </div>
                </form>
                <br>
                <?php if(@$_GET['lineproduksi'] && @$_GET['shift']): ?>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>
                                        <div style="width: 50px;">
                                            Line
                                        </div>
                                    </th>
                                    <th>
                                        <div style="width: 60px;">
                                            Lokasi
                                        </div>
                                    </th>
                                    <th>
                                        <div style="width: 60px;">
                                            Shift
                                        </div>
                                    </th>
                                    <th>
                                        <div style="width: 70px;">
                                            Jam Kerja
                                        </div>
                                    </th>
                                    <th>
                                        <div style="width: 200px;">
                                            Downtime
                                        </div>
                                    </th>
                                    <th>
                                        <div style="width: 200px;">
                                            Mulai
                                        </div>
                                    </th>
                                    <th>
                                        <div style="width: 200px">
                                            Finish
                                        </div>
                                    </th>
                                    <th>
                                        <div style="width: 200px;">
                                            Action Plan
                                        </div>
                                    </th>
                                    <th>
                                        <div style="width: 200px;">
                                            Lama Waktu
                                        </div>
                                    </th>
                                    <th>Gambar</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $perawatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($prw->lineproduksi->name); ?></td>
                                        <td><?php echo e($prw->lokasi->lokasi); ?></td>
                                        <td><?php echo e($prw->shift->name); ?></td>
                                        <td><?php echo e($prw->jamkerja->name); ?></td>
                                        <td><?php echo e($prw->downtime->name); ?></td>
                                        <td><?php echo e($prw->tanggal); ?></td>
                                        <td><?php echo e($prw->finish); ?></td>
                                        <td><?php echo e($prw->action_plan); ?></td>
                                        <td><?php echo e($prw->lama_waktu); ?></td>
                                        <td>
                                            <img src="<?php echo e(asset($prw->gambar)); ?>"
                                                alt=""
                                                width="100">
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="alert alert-danger">
                        <div class="text-center">
                            Data belum ada silhakan pilih indikator lain
                        </div>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php /**PATH E:\Pemrograman web\localhost\projekmesin\resources\views/pages/dashboard/maintenance-downtime/show.blade.php ENDPATH**/ ?>