<x-admin-layout>
    <div class="card">
        <div class="card-body">
            <div class="my-5">
                <div class="row">
                    <div class="col-md-6">
                        <h3>Lihat Presensi</h3>
                    </div>
                </div>
            </div>
            <iframe width="100%"
                height="1000"
                src="https://docs.google.com/spreadsheets/d/e/2PACX-1vR5BPdIZnbpP7KVPt2VmCoiTtSAKKu-8OdBqLVM8XlH2amR29kSncaEMscgT_GvKFRN8Lz8r8lWT2tO/pubhtml?widget=true&amp;headers=false"></iframe>
        </div>
    </div>
</x-admin-layout>
